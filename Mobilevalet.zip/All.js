import { StyleSheet, View,Text,ScrollView,Image,TextInput,Platform,Pressable} from 'react-native';



function AllComponent(){

   return(
    <View>
        <Text>AllComponent1</Text>
    </View>
   );

}


module.exports = AllComponent;