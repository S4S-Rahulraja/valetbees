import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import LoginComponent from './Login';
import HomeComponent from './Home';


const Stack = createStackNavigator();

function NavigationComponent() {
  return (
    <NavigationContainer>
       <Stack.Navigator initialRouteName="Home"  >
          <Stack.Screen name="Login" component={LoginComponent}  options={{ headerShown: false }} />
          <Stack.Screen name="Home" component={HomeComponent} options={{ headerShown: false }}/>
        </Stack.Navigator>
     </NavigationContainer>

  );
}





module.exports =  NavigationComponent;