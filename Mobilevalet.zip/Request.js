import { StyleSheet, View,Text,ScrollView,Image,TextInput,Platform,Pressable} from 'react-native';



function RequestComponent(){

   return(
    <View>
        <Text>RequestComponent</Text>
    </View>
   )

}


module.exports = RequestComponent;