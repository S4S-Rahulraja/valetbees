
import { StyleSheet, View,Text,ScrollView,Image,TextInput,Platform,Pressable,StatusBar} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const  HomeComponent = ({ navigation }) => {

  

    return (
        <View style={styles.allhomecontainer}>  
           <StatusBar style="auto"></StatusBar>
                <View style={styles.container}>
                    <Image style={styles.imageAlign} source={require('./assets/Logo.png')}/>
                    <Text style={styles.textAlign} >Valet Partner</Text>
                    <Image style={styles.logimgalign} source={require('./assets/loginpic.png')}/>
                </View>
                <View style={styles.tokenCenterAlign}>
                    <TextInput placeholder='Available Tokens , Active Tokens..' style={styles.tokenInputAlign} ></TextInput>
                    <Ionicons name="search" size={24} color="black" style={styles.searchIcon} />
                </View>

                <ScrollView>
                    <View style={styles.allpatalign}>
                           <View style={styles.allReq1}>
                                  <Text style={styles.allReqtext1}>Requests <Ionicons name="alarm" size={20} color="#FF9901" style={styles.reqIcon} /> </Text>
                                  <View style={styles.tokenAccept}>
                                      <Text style={styles.tokenAcceptText}>Token:5</Text>
                                  </View>
                           </View>
                           <View style={styles.allReq1}>
                                  <Text style={styles.allReqtext1}>Open <Ionicons name="open" size={20} color="#FF9901" style={styles.reqIcon} /> </Text>
                                  <View style={styles.tokenAccept}></View>
                           </View>
                           <View style={styles.allReq1}>
                                  <Text style={styles.allReqtext1}>Active <Ionicons name="checkmark-circle" size={20} color="#FF9901" style={styles.reqIcon} /> </Text>
                                  <View style={styles.tokenAccept}></View>
                           </View>
           
                
                    </View>
                </ScrollView>

                <View style={styles.footer}>
                  
                        <View style={styles.footButton1}>
                           
                                 <Ionicons name="home" size={24} color="#FF9901" style={styles.homeIcon} />
                                 <Text>All</Text>
                          
                        </View >
                     
                    <View style={styles.footButton1}>
                            <Ionicons name="alarm" size={24} color="#FF9901" style={styles.homeIcon} />
                            <Text>Requests</Text>
                    </View> 
                    <View style={styles.footButton1}>
                            <Ionicons name="open" size={24} color="#FF9901" style={styles.homeIcon} />
                            <Text>Open Slot</Text>
                    </View> 
                    <View style={styles.footButton1}>
                            <Ionicons name="checkmark-circle" size={24} color="#FF9901" style={styles.homeIcon} />
                            <Text>Active Slot</Text>
                    </View>                
                </View>
        </View>
    )
}


const styles = StyleSheet.create({
    allhomecontainer:{
      flex:1,
    },
    container: {
        backgroundColor: "#FF9901",
        width:"100%",
        height:65,
        flexDirection: 'row',
        alignItems:'center'
      
      },
      imageAlign: {
        width:45,
        height:45,
        marginLeft:10,
      },
      textAlign:{
        marginLeft:'auto',
        marginRight:-120,
        color:" rgba(0, 0, 0, 0.66)",
        fontSize: 20,
        fontWeight: 'normal',
      },
      logimgalign:{
        marginLeft:'auto',
        marginRight:20,
        width:40,
        height:40,
        zIndex:1
      },

      tokenCenterAlign:{
          display:'flex',
          justifyContent:'center',
          alignItems:'center'
      },

      tokenInputAlign:{
        borderWidth:1,
        borderColor:"#ccc",
        width:"90%",
        backgroundColor:"white",
        borderRadius:15,
        textAlign:"left",
        fontSize:15,
        paddingVertical: 13,
        paddingLeft:20,
        marginTop:10,
        ...Platform.select({
          ios: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 0 },
            shadowOpacity: 0.5,
            shadowRadius: 3,
          },
          android: {
            elevation: 6,
          },
        }),
      },
      searchIcon: {
        position: 'absolute',
        right: 40, 
        top: '60%',
        transform: [{ translateY: -12 }],
      },
      footer:{
        position: 'relative',
        bottom: 0,
        backgroundColor:'white' ,
        width:'100%',
        height:'auto',
        flexDirection: 'row',
        alignItems:'center',
        paddingLeft:5,
        paddingRight:10,
        paddingBottom:10,
        paddingTop:5,
        ...Platform.select({
            ios: {
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 0 },
              shadowOpacity: 0.5,
              shadowRadius: 20,
            },
            android: {
              elevation: 20,
            },
          }),
      },
      footButton1:{
        width:'25%',
        display:'flex',
        justifyContent:'center',
        alignItems:'center'
      },

      allpatalign:{
        paddingLeft:20,
        paddingRight:20,
        paddingTop:20,

      },
      allReq1:{
        backgroundColor:'white',
        borderRadius:15,
        width:'100%',
        height:150,
        marginBottom:30,
        elevation: 10,
        paddingLeft:10,
        paddingRight:10,
        paddingBottom:10,
        paddingTop:20,
      },
      allReqtext1:{
        fontSize:24,
        fontWeight:'bold',
        marginLeft:10
      },
      tokenAccept:{
        borderRadius: 6,
        border: "1px solid #FF990160",
        backgroundColor: "#FF990160",
        width: '100%',
        height: 33,
        marginTop:10,
        flexDirection: 'row',
        alignItems:'center',
        paddingLeft:10
      },
      tokenAcceptText:{
        fontSize:15,
        fontWeight:'normal',
      }
      
});



module.exports = HomeComponent;